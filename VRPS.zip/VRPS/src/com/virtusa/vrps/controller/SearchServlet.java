package com.virtusa.vrps.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.vrps.DAO.SearchDAO;
import com.virtusa.vrps.models.Employee;

/**
 * Servlet implementation class SearchServlet
 */
@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

			/**
			 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
			 */
				// TODO Auto-generated method stub
			String name=request.getParameter("ename");
			String name1=request.getParameter("name1");
			response.setContentType("text/html");
			SearchDAO sr=new SearchDAO();
			PrintWriter out=response.getWriter();
			
			switch(name1)
			{
			
			case "Email":
				
			
			{
				
				Employee e=sr.getByIdentity(name);
				if(e!=null) {
					
				
				out.print("<table border='2' width='500' align='center' height='100' style='postion:relative;margin-top:100px;'>");
				out.println("<tr>");
				out.println("<td>"+e.getName()+"</td>");
				out.println("<td>"+e.getUserName()+"</td>");
				out.println("<td>"+e.getEmail()+"</td>");
			    out.println("<td>"+e.getPhone()+"</td>");
			    out.println("</tr></table>");
				}
				else
				{
					out.println("<p align='center'>");
					out.println("<h2>"+"Sorry your data not found"+"</h2>");
					out.println("</p>");
				}
	break;
			
			}
			
			case "Referenceid":
			{	
				
	            Employee rf=sr.getByUserName(name);
				if(rf!=null) {
				out.print("<table border='2' width='500' align='center' height='100' style='postion:relative;margin-top:100px;'>");
				out.println("<tr>");
				out.println("<td>"+rf.getName()+"</td>");
				out.println("<td>"+rf.getUserName()+"</td>");
				
				out.println("<td>"+rf.getEmail()+"</td>");
			
			out.println("<td>"+rf.getPhone()+"</td>");
			out.println("</tr></table>");
				}
				else
					out.println("<h2 style='align:center'>"+"Sorry your data not found"+"</h2>");
			break;	
	}	 
			
			case "phone": 
			{	
	           
				Employee ph=sr.getByNumber(name);
				if(ph!=null) {
				out.print("<table border='2' width='500' align='center' height='100' style='postion:relative;margin-top:100px;'>");
				out.println("<tr>");
				out.println("<td>"+ph.getName()+"</td>");
				out.println("<td>"+ph.getUserName()+"</td>");
				
				out.println("<td>"+ph.getEmail()+"</td>");
			
			out.println("<td>"+ph.getPhone()+"</td>");
			out.println("</tr></table>");
				}
				else
					out.println("<h2 style=align:center;>"+"Sorry your data not found"+"</h2>");
	       break;  
			}		 
			case "Name":
			{
		
					
			
	            Employee na=sr.getByName(name);
				if(na!=null)
				{
				out.print("<table border='2' width='500' align='center' height='100' style='postion:relative;margin-top:100px;'>");
				out.println("<tr>");
				out.println("<td>"+na.getName()+"</td>");
				out.println("<td>"+na.getUserName()+"</td>");
				
				out.println("<td>"+na.getEmail()+"</td>");
			
			out.println("<td>"+na.getPhone()+"</td>");
			out.println("</tr></table>");
				}
				else
					out.println("<h2>"+"Sorry your data not found"+"</h2>");
		break;
			}
		
		
			

			}

	}

}
