package com.virtusa.vrps.DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

import com.virtusa.vrps.models.AdminStatus;
import com.virtusa.vrps.models.Applied;


public class AppliedDAO {
	public ArrayList<Applied> get() {
		// TODO Auto-generated method stub
		String sqlQuery = "select a.Employeeid,a.firstname,a.lastname,b.status from applicationtable2 a inner join adminstatus b on a.employeeid=b.employeeid";
		ArrayList<Applied> Employees = new ArrayList<Applied>();

		try (Connection con = Dbutils.buildConnection();
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(sqlQuery)) {
			while (rs.next()) {
				String id=rs.getString(1);
				String firstname=rs.getString(2);
				String lastname=rs.getString(3);
				String statusname=rs.getString(4);
				Applied s = new Applied(id, firstname, lastname, statusname);
				Employees.add(s);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return Employees;
	}

}
