package com.virtusa.vrps.DAO;

import java.util.ArrayList;

import com.virtusa.vrps.models.AdminStatus;

public class IndividualDAO {
String id;
String status;
String review;
String id1;
String status1;
String review1;
public IndividualDAO(String id, String status, String review) {

	this.id = id;
	this.status = status;
	this.review = review;
}
public String getId() {
	return id;
}
public String getStatus() {
	return status;
}
public String getReview() {
	return review;
}
public void display() {
	AdminStatusDAO asd=new AdminStatusDAO();
	ArrayList <AdminStatus> as= asd.getAllStatus();	
	for(int i=0;i<as.size();i++) {
		System.out.println(as.get(i));
		
	}
}
public AdminStatus actualData() {
	int j=0;
	AdminStatusDAO asd=new AdminStatusDAO();
	ArrayList <AdminStatus> as= asd.getAllStatus();
	 for(int i=0;i<as.size();i++) {
	 if(getId().equals(as.get(i).getEmployeeid()))
	 {
	id1 = getId();
	j++;
	 }
	 else id1=null;
	 if(getStatus().equals(as.get(i).getStatus1()))
	 {
	status1=getStatus();
	j++;
	 }
	 
	 else status1=null;
	 
	 if(getReview().equals(as.get(i).getReview()))
	 {
	review1=getReview();
	j++;
	 }
	 else
		 review1=null;
	 
	 if(j==3)
	 break;
	 
	 }
	 return new AdminStatus(id1,status1,review1);
	
	
}
}



