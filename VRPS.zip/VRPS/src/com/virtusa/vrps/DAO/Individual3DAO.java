package com.virtusa.vrps.DAO;

import java.util.ArrayList;

import com.virtusa.vrps.models.Application;
import com.virtusa.vrps.models.Employee;


public class Individual3DAO 
{
	String employeeid;
    String Firstname;
     String Middlename;
	 String Lastname;
	 String Email;
	 String Phonenumber;
	 String degree;
	 String degreemarks;
	 String inter;
	 String intermarks;
	 String tenth;
	 String tenthmarks;
      String avialdate;
	 String jobslevel;
	 String jobstatus;
	 String employeeid1;
	    String Firstname1;
	     String Middlename1;
		 String Lastname1;
		 String Email1;
		 String Phonenumber1;
		 String degree1;
		 String degreemarks1;
		 String inter1;
		 String intermarks1;
		 String tenth1;
		 String tenthmarks1;
	      String avialdate1;
		 String jobslevel1;
		 String jobstatus1;
	 
	 public Individual3DAO(String employeeid, String firstname, String middlename, String lastname, String email,
			String phonenumber, String degree, String degreemarks, String inter, String intermarks, String tenth,
			String tenthmarks, String avialdate, String jobslevel, String jobstatus) {
		super();
		this.employeeid = employeeid;
		Firstname = firstname;
		Middlename = middlename;
		Lastname = lastname;
		Email = email;
		Phonenumber = phonenumber;
		this.degree = degree;
		this.degreemarks = degreemarks;
		this.inter = inter;
		this.intermarks = intermarks;
		this.tenth = tenth;
		this.tenthmarks = tenthmarks;
		this.avialdate = avialdate;
		this.jobslevel = jobslevel;
		this.jobstatus = jobstatus;
	}
	public String getEmployeeid() {
		return employeeid;
	}
	public void setEmployeeid(String employeeid) {
		this.employeeid = employeeid;
	}
	public String getFirstname() {
		return Firstname;
	}
	public void setFirstname(String firstname) {
		Firstname = firstname;
	}
	public String getMiddlename() {
		return Middlename;
	}
	public void setMiddlename(String middlename) {
		Middlename = middlename;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getPhonenumber() {
		return Phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		Phonenumber = phonenumber;
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	public String getDegreemarks() {
		return degreemarks;
	}
	public void setDegreemarks(String degreemarks) {
		this.degreemarks = degreemarks;
	}
	public String getInter() {
		return inter;
	}
	public void setInter(String inter) {
		this.inter = inter;
	}
	public String getIntermarks() {
		return intermarks;
	}
	public void setIntermarks(String intermarks) {
		this.intermarks = intermarks;
	}
	public String getTenth() {
		return tenth;
	}
	public void setTenth(String tenth) {
		this.tenth = tenth;
	}
	public String getTenthmarks() {
		return tenthmarks;
	}
	public void setTenthmarks(String tenthmarks) {
		this.tenthmarks = tenthmarks;
	}
	public String getAvialdate() {
		return avialdate;
	}
	public void setAvialdate(String avialdate) {
		this.avialdate = avialdate;
	}
	public String getJobslevel() {
		return jobslevel;
	}
	public void setJobslevel(String jobslevel) {
		this.jobslevel = jobslevel;
	}
	public String getJobstatus() {
		return jobstatus;
	}
	public void setJobstatus(String jobstatus) {
		this.jobstatus = jobstatus;
	}
	
	public void display() {
		ApplicationDAO asd=new ApplicationDAO();
		ArrayList <Application> as= asd.getAllApply();	
		for(int i=0;i<as.size();i++) {
			System.out.println(as.get(i));
			
		}
	}
	public Application actualData() 
	{
		int j=0;
		ApplicationDAO asd=new ApplicationDAO();
		ArrayList <Application> as= asd.getAllApply();
		 for(int i=0;i<as.size();i++)
		 {
		 if(getEmployeeid().equals(as.get(i).getEmployeeid()))
		 {
		employeeid1 = getEmployeeid();
		j++;
		 }
		 else employeeid1=null;
		 if(getFirstname().equals(as.get(i).getFirstname()))
		 {
		Firstname1=getFirstname();
		j++;
		 }
		 else
			 Firstname1=null;
		 
		 if(getMiddlename().equals(as.get(i).getMiddlename()))
		 {
		Middlename1=getMiddlename();
		j++;
		 }
		 else
			 Middlename1=null;
		 
		 
		
		 
		 
		 if(getLastname().equals(as.get(i).getLastname()))
		 {
		Lastname1=getLastname();
		j++;
		 }
		 else
			 Lastname1=null;
		 
		 if(getEmail().equals(as.get(i).getEmail()))
		 {
		Email1=getEmail();
		j++;
		 }
		 
		 else Email1=null;
		 
		 if(getPhonenumber().equals(as.get(i).getPhonenumber()))
		 {
		Phonenumber1=getPhonenumber();
		j++;
		 }
		 else
			 Phonenumber1=null;
		 if(getDegree().equals(as.get(i).getDegree()))
		 {
		degree1=getDegree();
		j++;
		 }
		 else
			 degree1=null;
		 
		 if(getDegreemarks().equals(as.get(i).getDegreemarks()))
		 {
		degreemarks1=getDegreemarks();
		j++;
		 }
		 else
			 degreemarks1=null;
		 if(getInter().equals(as.get(i).getInter()))
		 {
		inter1=getInter();
		j++;
		 }
		 else
			 inter1=null;
		 if(getIntermarks().equals(as.get(i).getIntermarks()))
		 {
		intermarks1=getIntermarks();
		j++;
		 }
		 else
			 intermarks1=null;
		 if(getTenth().equals(as.get(i).getTenth()))
		 {
		tenth1=getTenth();
		j++;
		 }
		 else
			 tenth1=null;
		 if(getTenthmarks().equals(as.get(i).getTenthmarks()))
		 {
		tenthmarks1=getTenthmarks();
		j++;
		 }
		 else
			 tenthmarks1=null;
		 if(getAvialdate().equals(as.get(i).getAvialdate()))
		 {
		avialdate1=getAvialdate();
		j++;
		 }
		 else
			 avialdate1=null;
		 if(getJobslevel().equals(as.get(i).getJobslevel()))
		 {
		jobslevel1=getJobslevel();
		j++;
		 }
		 else
			 jobslevel1=null;
		 if(getJobstatus().equals(as.get(i).getJobstatus()))
		 {
		jobstatus1=getJobstatus();
		j++;
		 }
		 else
			 jobstatus1=null;
		 
		 if(j==15)
			 break;
		 }
		 return new Application(employeeid1, Firstname1, Middlename1,Lastname1 , Email1, Phonenumber1,degree1,degreemarks1,inter1,intermarks1,tenth1,tenthmarks1,avialdate1,jobslevel1,jobstatus1);
	}
	}
	

