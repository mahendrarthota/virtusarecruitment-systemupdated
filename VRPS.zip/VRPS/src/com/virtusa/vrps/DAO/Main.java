package com.virtusa.vrps.DAO;

import com.virtusa.vrps.models.AdminStatus;

public class Main {
public static void main(String args[]) {
	AdminStatus astest=new AdminStatus("8063516","recruited","notwell");
	IndividualDAO i=new IndividualDAO("8063516","recruited","");
	IndividualDAO i2=new IndividualDAO("8063516","recruited","");
	if("".equals(null))
		System.out.println("hh");
	if(i.actualData().equals(i2.actualData()))
		System.out.println(i.actualData()+" "+" equals"+" "+i2.actualData());
	else
		System.out.println(i.actualData()+" "+" not equal"+" "+i2.actualData());
System.out.println(astest);	
i2.display();
i.display();
}
}
